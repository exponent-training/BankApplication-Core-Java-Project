package com.exponent.bankapplication.ServiceImpl;

import java.util.Scanner;
import java.util.regex.Pattern;

import com.exponent.bankapplication.Model.Account;
import com.exponent.bankapplication.Service.RBI.RBIrules;

public class HDFC implements RBIrules {

	// Created Scanner Class
	Scanner sc = new Scanner(System.in);

	// This is Array of the Account Class
	Account[] ac = new Account[10];

	int count = 0;

	// This is Object of the Account Class
	Account acc = new Account();

	@Override
	public void createAccount() {
		System.out.println("Enter How Many Account You want to Create: ");
		int numberofAcc = sc.nextInt();
		sc.nextLine();

		for (int i = 0; i < numberofAcc; i++) {
			Account acc = new Account();

			// Account Number
			acc.setAccountNumber(validAccountNumber());
			
			// Name Setting
			sc.nextLine();
			acc.setHolderName(validName());
			
			//Address
			System.out.println();
			System.out.println("Enter address of Account Holder:");
			acc.setAddress(sc.next());;

			// Aadhar-Card Number
			sc.nextLine();
			acc.setAadharCardNumber(validAadharcard());

			// Pan-card Number
			acc.setPanCardNumber(validPanNumber());

			// Phone Number
			acc.setContactNumber(validContactNumber());

			// Email-Id
			acc.setEmailID(validEmail());

			System.out.println("Enter your Opening Amount: ");
			acc.setAccountBalance(sc.nextDouble());
			sc.nextLine();

			ac[count] = acc;
			count++;

			System.out.println("Sucessfully Created Your Account!!!!!!!!");
		}

	}

	// Account Number validation
	private long validAccountNumber() {
		System.out.println("Enter Your Account Number: ");
		long accountNumber = sc.nextLong();
		String pattern = "[0-9]{12}";
		String accNoString = String.valueOf(accountNumber);
		if (Pattern.matches(pattern, accNoString.trim()) && accNoString.length() == 12) {
			System.out.println("Valid  account no added");
		} else {
			System.out.println("Invalid account  no  , Account  no  should be  of  12 digit");
			return validAccountNumber();
		}

		if (checkAccountNumber(accountNumber)) {
			System.out.println("Account Number already exists, please enter a different number.");
			return validAccountNumber();
		}
		return accountNumber;

	}
	
	// Name validation
		private String validName() {
			System.out.println("Enter Account Holder's Name: ");
			String name = sc.nextLine();

			if (Pattern.matches("[a-zA-Z ]+", name)) {
				System.out.println("Valid name added");
			} else {
				System.out.println("Invalid account name");
				return validName();
			}
			return name;
		}

		// Normal way
//		private String validName() {
//			System.out.println("Enter your Name:");
//			String name = sc.nextLine().trim();
//			char[] charName = name.toCharArray();
//			boolean flag = false;
//			int countSpace = 0;
//			for(int i = 0; i< charName.length;i++) {
//				if(!(name.charAt(i) >= 'a' && name.charAt(i) <= 'z' || name.charAt(i) >= 'A' && name.charAt(i) <= 'Z' || name.charAt(i) == ' ')) {
//					flag = true;
//				}
//				if(name.charAt(i) == ' ') {
//					countSpace ++ ;
//				}
//			}
//			
//			if(flag) {
//				System.out.println("Invalid Name, Please Enter Correct Name: ");
//				return validName();
//			}else if(countSpace < 2) {
//				System.out.println("Invalid Name, Please Enter Full Name: ");
//				return validName();
//			}else {
//				return name;
//			}
//		}


	private boolean checkAccountNumber(long accountNumber) {
		for (int i = 0; i < count; i++) {
			if (ac[i].getAccountNumber() == accountNumber) {
				return true;
			}
		}
		return false;
	}

	// Aadharcard validation
	private String validAadharcard() {
		System.out.println("Enter your Aadharcard Number: ");

		String aadharNo = sc.nextLine();
		if (Pattern.matches("^[2-9]{1}[0-9]{3}[ -]?[0-9]{4}[ -]?[0-9]{4}$", aadharNo) && aadharNo.length() == 14
				&& aadharNo != null) {
			System.out.println("Valid Aadhar card no added");
		} else {
			System.out.println("Invalid Aadhar no , only 12 digit numbers allowed ");
			return validAadharcard();
		}
		return aadharNo;

	}

	// Pancard validation
	private String validPanNumber() {
		System.out.println("Enter Your Pancard Number: ");
		String panNumber = sc.next();
		String pattern = "[A-Z]{5}[0-9]{4}[A-Z]{1}";

		if (Pattern.matches(pattern, panNumber) && panNumber.length() == 10 && panNumber != null) {
			System.out.println("Valid Pan card no added");
		} else {
			System.out.println("Invalid Pan card no ,only 10 alphanumeric  are allowed");
			return validPanNumber();
		}

		return panNumber;
	}

	// Phone Number Validation
	private long validContactNumber() {
		System.out.println("Enter Your Phone Number: ");
		long phoneNumber = sc.nextLong();
		String pattern = "[0-9]{10}";
		String phoneNoString = String.valueOf(phoneNumber);

		if (Pattern.matches(pattern, phoneNoString) && phoneNoString.length() == 10) {
			System.out.println("Valid contact Number");
		} else {
			System.out.println("Invalid contact Number!!, Please Enter 10 Digit Contact Number");
			return validContactNumber();
		}

		return phoneNumber;
	}

	// Email Validation
	private String validEmail() {
		System.out.println("Enter Your Email-Id: ");
		String mailId = sc.next();

		if (Pattern.matches("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}", mailId)) {
			System.out.println("Valid emailid added");
		} else {
			System.out.println("Invalid email id");
			return validEmail();
		}
		return mailId;
	}

	@Override
	public void showAccountDetails() {
		System.out.println("********YOUR ACCOUNT DETAILS********");

		System.out.println("Enter your Account Number: ");
		long accnumber = sc.nextLong();

		boolean flag = false;

		for (Account account : ac) {
			if (account != null && accnumber == account.getAccountNumber()) {

				System.out.println(account);

				flag = true;
				break;

			}
		}
		if (!flag) {
			System.out.println("Account Does Not Exist");
		}

	}

	@Override
	public void showAccountBalance() {
		System.out.println("********IN CURRENT BALANCE SECTION********");

		System.out.println("Enter your Account Number: ");
		long accnumber = sc.nextLong();

		boolean flag = false;

		for (Account account : ac) {
			if (account != null && accnumber == account.getAccountNumber()) {
				System.out.println("Your Current Balance is: " + account.getAccountBalance());

				flag = true;
				break;
			}
		}

		if (!flag) {
			System.out.println("Account Does Not Exist");
		}

	}

	@Override
	public void depositMoney() {
		System.out.println("*******IN DEPOSIT SECTION*******");

		System.out.println("Enter your Account Number: ");
		long accnumber = sc.nextLong();

		boolean flag = false;

		for (Account account : ac) {
			if (account != null && accnumber == account.getAccountNumber()) {
				System.out.println("Enter the Amount: ");
				double amount = sc.nextDouble();
				double updateamount = account.getAccountBalance() + amount;
				account.setAccountBalance(updateamount);
				System.out.println("Your Current Balance is: " + updateamount);

				flag = true;
				break;
			}
		}
		if (!flag) {
			System.out.println("Account Does Not Exist");
		}

	}

	@Override
	public void withdrawMoney() {
		System.out.println("*******IN WITHDRAW SECTION*******");

		System.out.println("Enter your Account Number: ");
		long accnumber = sc.nextLong();

		boolean flag = false;

		for (Account account : ac) {
			if (account != null && accnumber == account.getAccountNumber()) {
				System.out.println("Enter the Amount you want to Withdraw");
				double amount = sc.nextDouble();
				if (amount < account.getAccountBalance()) {
					double updatedamount = account.getAccountBalance() - amount;
					account.setAccountBalance(updatedamount);
					System.out.println("Balance after Withdraw is: " + updatedamount);

				} else {
					System.out.println("<--------Insufficient Balance-------->");
				}

				flag = true;
				break;
			}
		}
		if (!flag) {
			System.out.println("Account Does Not Exist");
		}

	}

	@Override
	public void updateDetails() {
		System.out.println("*******IN UPDATE DETAILS SECTION*******");
		System.out.println("Enter your Account Number: ");
		long accnumber = sc.nextLong();

		boolean flag = false;

		for (Account account : ac) {
			if (account != null && accnumber == account.getAccountNumber()) {
				boolean flag1 = true;

				while (flag1) {
					System.out.println("-----------------------------------");
					System.out.println("-----------------------------------");
					System.out.println("        1: UPDATE NAME             ");
					System.out.println("        2: UPDATE CONTACT NUMBER   ");
					System.out.println("        3: UPDATE EMAIL-ID         ");
					System.out.println("        4: UPDATE ADDRESS         ");
					System.out.println("        5: EXIT                    ");
					System.out.println("-----------------------------------");
					System.out.println("-----------------------------------");

					System.out.println("Enter Your Choice: ");
					int ch = sc.nextInt();
					sc.nextLine();
					switch (ch) {
					case 1:
						account.setHolderName(updateName());
						System.out.println("<----------Successfully Updated The Name---------->");
						break;
					case 2:
						account.setContactNumber(updateContact());
						System.out.println("<----------Successfully Updated The Contact Number---------->");
						break;
					case 3:
						account.setEmailID(updateEmail());
						System.out.println("<----------Successfully Updated The Email-ID---------->");
						break;
					case 4:
						account.setAddress(updateAddress());
						System.out.println("<----------Successfully Updated The Address---------->");
						break;
					case 5:
						flag1 = false;
						break;
					default:
						System.out.println("Wrong Choice, Please Enter between 1-4");
						break;
					}

				}
				flag = true;
				break;
			}
		}
		if (!flag) {
			System.out.println("Account Does Not Exist");
		}

	}

	private String updateAddress() {
		System.out.println("Enter updated address:");
		String updatedAddress = sc.next();
		return updatedAddress;
	}

	public String updateName() {
		System.out.println("Enter your Name: ");
		String newName = sc.nextLine().trim();
		if (Pattern.matches("[a-zA-Z ]+", newName)) {
			System.out.println("Valid name added");
		} else {
			System.out.println("Invalid account name");
			return validName();
		}
		return newName;
	}

//	public void updateName(Account ac) {
//		System.out.println("Enter your Name: ");
//		String newName = sc.next().trim();
//		ac.setHolderName(newName);
//		System.out.println("Your Updated Name is: "+ newName);
//		
//		System.out.println("<----------Successfully Updated The Name---------->");
//	}

	public long updateContact() {
		System.out.println("Enter your Phone Number: ");
		long newNumber = sc.nextLong();
		String phoneNoString = String.valueOf(newNumber);

		if (Pattern.matches("[0-9]{10}", phoneNoString) && phoneNoString.length() == 10) {
			System.out.println("Valid contact Number");
		} else {
			System.out.println("Invalid contact Number!!, Please Enter 10 Digit Contact Number");
			return updateContact();
		}
		return newNumber;
	}

//	public void updateContact(Account ac) {
//		System.out.println("Enter your Phone Number: ");
//		long newNumber = sc.nextLong();
//		
//		ac.setContactNumber(newNumber);
//		System.out.println("Your Updated Name is: "+ newNumber);
//		
//		System.out.println("<----------Successfully Updated The Contact Number---------->");
//	}

	public String updateEmail() {
		System.out.println("Enter your Email-ID: ");
		String newEmail = sc.next();

		if (Pattern.matches("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}", newEmail)) {
			System.out.println("Valid emailid added");
		} else {
			System.out.println("Invalid email id");
			return updateEmail();
		}
		return newEmail;
	}

//	public void updateEmail(Account ac) {
//		System.out.println("Enter your Email-ID: ");
//		String newEmail = sc.next();
//		
//		ac.setEmailID(newEmail);
//		System.out.println("Your Updated Name is: "+ newEmail);
//		
//		System.out.println("<----------Successfully Updated The Email-ID---------->");
//	}

}
