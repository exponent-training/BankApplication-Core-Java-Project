package com.exponent.bankapplication.Model;
public class Account {
	
	
	private long accountNumber;
	private String holderName;
	private String address;
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	private String aadharCardNumber;
	private String panCardNumber;
	private long contactNumber;
	private String emailID;
	private double accountBalance;
	
	
	public long getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getHolderName() {
		return holderName;
	}
	public void setHolderName(String holderName) {
		this.holderName = holderName;
	}
	
	public String getPanCardNumber() {
		return panCardNumber;
	}
	public void setPanCardNumber(String panCardNumber) {
		this.panCardNumber = panCardNumber;
	}
	public long getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getEmailID() {
		return emailID;
	}
	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}
	public double getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}
	
	
	@Override
	public String toString() {
		return "Account Detalis [ " +
				 "\n AccountNumber=" + accountNumber + 
				"\n Account Holder Name=" + holderName + 
				"\n Addharcard Number="+ aadharCardNumber + 
				"\n Pancard Number=" + panCardNumber + 
				"\n Contact Number=" + contactNumber +
				"\n EmailID=" + emailID + 
				"\n Account Balance=" + accountBalance + 
				"\n Address=" + address +"]";
	}
	public String getAadharCardNumber() {
		return aadharCardNumber;
	}
	public void setAadharCardNumber(String aadharCardNumber) {
		this.aadharCardNumber = aadharCardNumber;
	}
	
	

}
